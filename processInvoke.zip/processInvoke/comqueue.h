#ifndef COMQUEUE_H
#define COMQUEUE_H
#include "readyqueue.h"

class ComQueue
{
public:
    ComQueue();
    PCB* Pop();
    void Push(PCB* pcb);
    void DeQueue(PCB* p);
    PCB* getPCBByName(QString name);
    int getCount();
    PCB* getNode();
private:
    PCB* node=new PCB("node",0,0,0,0);
    int count=0;
};

#endif // COMQUEUE_H
