#include "readyqueue.h"
#include <QDebug>
readyQueue::readyQueue()
{

}
PCB* readyQueue::Pop(){
    if(count<=0){

    }else{
       PCB* pcb=pcbNode->pcbNext;
       pcbNode->pcbNext=pcb->pcbNext;
       count--;
       pcb->pcbNext=NULL;
       return pcb;
    }
}

bool readyQueue::IsReadyQueueEmpty(){
    if(count==0){
        return true;
    }else{
        return false;
    }
}

bool readyQueue::Push(PCB* pcb){//入队，按优先级
    qDebug()<<"aaaaaa";
        PCB* node=pcbNode;
            while(node->pcbNext!=NULL){
                if(node->pcbNext->priority<pcb->priority){
                    pcb->pcbNext=node->pcbNext;
                    node->pcbNext=pcb;
                    count++;
                    return true;
                }
                node=node->pcbNext;
            }
            node->pcbNext=pcb;
            count++;
            return true;

    qDebug()<<count;
}

void readyQueue::DeQueue(PCB *p){
    PCB* p2=pcbNode;
    while(p2->pcbNext!=NULL){
        if(p2->pcbNext->PCBName.compare(p->PCBName)==0){
            p2->pcbNext=p2->pcbNext->pcbNext;
            p->pcbNext=NULL;
            count--;
            return;
        }
        p2=p2->pcbNext;
    }
}

PCB* readyQueue::getPCBByName(QString name){
    PCB* p=pcbNode->pcbNext;
    while(p!=NULL){
       if(p->PCBName.compare(name)==0){
           return p;
       }
        p=p->pcbNext;
    }
    return NULL;
}
