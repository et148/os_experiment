#include "widget.h"
#include "readyqueue.h"
#include <QLineEdit>
#include "ui_widget.h"
#include <QInputDialog>
#include <QString>
#include <QStringList>
#include <QDebug>
#include <iostream>
#include <QTime>
#include <QTimer>
#include <QList>
#include <QMessageBox>
#include <QTableWidget>
#include <QHeaderView>

using namespace std;
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    //对表的初始化
    tableWidget->resize(320,221);
    tableWidget->move(550,80);
    tableWidget->horizontalHeader()->setStretchLastSection(true);
    tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);//设置每次选择一行
    tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);//设置不可编辑
    tableWidget->verticalHeader()->setVisible(false);
    for(int i=0;i<1;i++){
        tableWidget->setRowHeight(i,20);
    }
    QStringList header;
    header<<tr("起址")<<tr("长度")<<tr("状态");
    tableWidget->setHorizontalHeaderLabels(header);
    QTableWidgetItem *item0,*item1,*item2;
    item0=new QTableWidgetItem;
    item1=new QTableWidgetItem;
    item2=new QTableWidgetItem;

    item0->setText(tr("0"));
    item0->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
    item1->setText(tr("520"));//设置内存为520
    item1->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
    item2->setText(tr("未分"));
    item2->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);

    tableWidget->setItem(0,0,item0);
    tableWidget->setItem(0,1,item1);
    tableWidget->setItem(0,2,item2);

    QTimer * timer=new QTimer(this);
    connect(timer,&QTimer::timeout,this,&Widget::update);
    timer->start(3000);
}

Widget::~Widget()
{
    delete ui;
}

//将进程表示成表项，表示的很粗糙
QString Widget::itemShow(PCB *p){
    QString sRunTime=QString::number(p->runTime,10);
    QString sPriority=QString::number(p->priority,10);
    QString sAddressLength=QString::number(p->addressLength,10);
    QString sStartAddress=QString::number(p->startAddress,10);
    QString s=p->PCBName+"             "+sRunTime+"             "
            +sPriority+"              "+p->state+"             "
            +sAddressLength+"           "+sStartAddress;

    return s;
}

bool Widget::ISrun(){
   if(ui->runList->count()==0){
       return false;
   }else{
       return true;
   }
}
void Widget::updatePend(int ok,PCB* p){  //更新挂起队列
    if(ok==1){  //表示进挂起队列引起的更新
        ui->pendList->addItem(itemShow(p));
    }else{      //表示由出挂起队列引起的更新
        int c=ui->pendList->count();
        for(int i=0;i<c;i++){
            QListWidgetItem* it=ui->pendList->takeItem(0);
            delete it;
        }
        PCB* p2=pendprocess.getNode();
        p2=p2->pcbNext;
        for(int i=0;i<pendprocess.getCount();i++,p2=p2->pcbNext){
            ui->pendList->addItem(itemShow(p2));
        }
    }
}

void Widget::updatePool(int ok,PCB* p){   //更新后备队列
    if(ok==1){   //表示进后备队列引起的更新
      ui->poolList->addItem(new QListWidgetItem(itemShow(p)));
    }else{     //表示由出挂起队列引起的更新
        int c=ui->poolList->count();
        for(int i=0;i<c;i++){
            QListWidgetItem* it=ui->poolList->takeItem(0);
            delete it;
        }
        PCB* p2=poolprocess.getNode()->pcbNext;
        for(int i=0;i<poolprocess.getCount();i++,p2=p2->pcbNext){
            ui->poolList->addItem(itemShow(p2));
        }
       }
}

void Widget::update(){//更新界面显示
    if(pendprocess.getCount()!=0){ //设置的是自动解挂，条件为就绪队列没满，在就后备队列前面
        for(int i=0;i<pendprocess.getCount();i++){
           PCB* p=pendprocess.getNode()->pcbNext;
           if(ISAnySpace(p->addressLength)){
               PCB* p1=p;
               p1->startAddress=divideSpace(p->addressLength);
               pendprocess.DeQueue(p);
               p1->state="ready";
               rPCB.Push(p1);
           }
        }
            updatePend(0,NULL);
    }
    if(poolprocess.getCount()!=0){//后备队列进就绪队列
        for(int i=0;i<poolprocess.getCount();i++){
            PCB* p=poolprocess.getNode()->pcbNext;
            if(ISAnySpace(p->addressLength)){
                PCB* p1=p;
                p1->startAddress=divideSpace(p->addressLength);
                poolprocess.DeQueue(p);
                p1->state="ready";
                rPCB.Push(p1);
            }
        }
        updatePool(0,NULL);
    }
    updateReady();
    if(runPCB!=NULL){//如果有运行的线程
        runPCB->priority--;
        runPCB->runTime--;
        if(runPCB->runTime==0){//如果运行线程运行时间变为0，更新线程
            recycleSpace(runPCB);//回收内存
            if(!rPCB.IsReadyQueueEmpty()){  //就绪队列非空
                PCB* p=rPCB.Pop();
                runPCB=p;
                p->state="run";
                QListWidgetItem* it=ui->runList->takeItem(0);
                delete it;
                updateRun(p);
                //因为就绪队列出去了一个，需要对挂起队列和后备队列再次更新
                if(pendprocess.getCount()!=0){
                    for(int i=0;i<pendprocess.getCount();i++){
                       PCB* p=pendprocess.getNode()->pcbNext;
                       if(ISAnySpace(p->addressLength)){
                           PCB* p1=p;
                           p1->startAddress=divideSpace(p1->addressLength);
                           pendprocess.DeQueue(p);
                           p1->state="ready";
                           rPCB.Push(p1);
                       }
                    }
                        updatePend(0,NULL);
                }
                if(poolprocess.getCount()!=0){//后备队列进就绪队列
                    for(int i=0;i<poolprocess.getCount();i++){
                        PCB* p=poolprocess.getNode()->pcbNext;
                        if(ISAnySpace(p->addressLength)){
                            PCB* p1=p;
                            poolprocess.DeQueue(p);
                            p1->state="ready";
                            rPCB.Push(p1);
                        }
                    }
                    updatePool(0,NULL);
                }
                updateReady();
            }else{//就绪队列为空
                QListWidgetItem* it=ui->runList->takeItem(0);
                delete it;
                runPCB=NULL;
            }

        }else{//runPCB还没有结束，重新按优先权排序
            if(!rPCB.IsReadyQueueEmpty()){
                if(runPCB->priority<rPCB.getNode()->pcbNext->priority){
                    PCB* p=runPCB;
                    p->state="ready";
                    rPCB.Push(p);
                    runPCB=rPCB.Pop();
                    runPCB->state="run";
                    updateReady();
                }
            }
            QListWidgetItem* it=ui->runList->takeItem(0);
            delete it;
            updateRun(runPCB);
        }
    }else if(rPCB.getCount()!=0){//没有正在运行的，但是有就绪的线程
        runPCB=rPCB.Pop();
        runPCB->state="run";
        updateRun(runPCB);
        updateReady();
    }
}

void Widget::updateRun(PCB* p){
    ui->runList->addItem(itemShow(p));
}

void Widget::updateReady(){
    int c=ui->readyList->count();
     for(int i=0;i<c;i++){
         QListWidgetItem* it=ui->readyList->takeItem(0);
         delete it;
     }
     PCB* p2=rPCB.getNode();
     p2=p2->pcbNext;
     for(int i=0;i<rPCB.getCount();i++,p2=p2->pcbNext){
         ui->readyList->addItem(itemShow(p2));
     }
}

//增加线程ok，全部加到后备队列
void Widget::addProcess(PCB* p){
       p->state="pool";
       poolprocess.Push(p);
       updatePool(1,p);
}
//增加线程的信号与槽ok
void Widget::on_addProcess_clicked()
{
    bool isok1;
    QString name=QInputDialog::getText(this,tr("Input"),tr("Input Process Name"),QLineEdit::Normal,tr(""),&isok1);
    if(isok1){
     bool isok2;
     QString rt=QInputDialog::getText(this,tr("Input"),tr("Input Process Runtime"),QLineEdit::Normal,tr(""),&isok2);
     int runtime=rt.toInt();
     if(isok2){
     bool isok3;
     QString pr=QInputDialog::getText(this,tr("Input"),tr("Input Process Priority"),QLineEdit::Normal,tr(""),&isok3);
     int priority=pr.toInt();
     if(isok3){
     bool isok4;
     QString len=QInputDialog::getText(this,tr("Input"),tr("Input Process Size"),QLineEdit::Normal,tr(""),&isok4);
     int addressLength=len.toInt();
     if(isok4){
         PCB* p=new PCB(name,runtime,priority,addressLength);
             addProcess(p);
            // qDebug()<<p->startAddress;     
      }
     }

   }
 }
}


//挂起ok
void Widget::on_pendProcess_clicked()
{
   bool ok;
   QString name=QInputDialog::getText(this,tr("Input"),tr("Input the process name you want to pend"),QLineEdit::Normal,tr(""),&ok);
   if(ok){
       if(runPCB->PCBName.compare(name)==0){//对运行线程的挂起,ok
           //更新界面
           qDebug()<<"cc";
           pendprocess.Push(runPCB);     //加到挂起队列
           qDebug()<<"ok";
           runPCB->state="pend";
           recycleSpace(runPCB);
           qDebug()<<"dddddddddddddd";
           updatePend(1,runPCB);         //更新界面
           if(!rPCB.IsReadyQueueEmpty()){//就绪队列非空
               runPCB=rPCB.Pop();            //就绪队列首进运行状态
               QListWidgetItem* it= ui->runList->takeItem(0);
               delete it;
               runPCB->state="run";
               updateRun(runPCB);            //更新运行界面
               qDebug()<<poolprocess.getCount();
               if(poolprocess.getCount()!=0){
                   PCB* p=poolprocess.Pop();
                   p->state="ready";
                   rPCB.Push(p);
                   updateReady();
                  updatePool(0,NULL);
               }else{
                  updateReady();
               }
           }else{
               QListWidgetItem* it=ui->runList->takeItem(0);
               delete it;
               runPCB=NULL;
           }
       }else{//否则就是对就绪队列的挂起
           PCB* p=rPCB.getPCBByName(name);
           qDebug()<<p->PCBName;
           recycleSpace(p);
           rPCB.DeQueue(p);
           qDebug()<<"2";
           p->state="pend";
           pendprocess.Push(p);
           qDebug()<<"2";
           updatePend(1,p);
           qDebug()<<poolprocess.getCount();
           if(poolprocess.getCount()!=0){
               PCB* p=poolprocess.Pop();
               p->state="ready";
               rPCB.Push(p);
               updateReady();
               updatePool(0,NULL);
           }else{
              updateReady();
           }
       }
   }

}
//有没有内存空间
bool Widget::ISAnySpace(int space){
    int i;
   for(i=0;i<tableWidget->rowCount();i++){
       qDebug()<<"abcd";
       if(tableWidget->item(i,1)->text().toInt()>=space){
           return true;
       }
   }
   return false;
}
//分配内存空间，并返回分配的起址
int Widget::divideSpace(int space){
    for(int i=0;i<tableWidget->rowCount();i++){
        if(tableWidget->item(i,1)->text().toInt()>=space){
             int start=tableWidget->item(i,0)->text().toInt();//得到原来的起址
             tableWidget->item(i,0)->setText(QString::number((start+space),10));
             int len=tableWidget->item(i,1)->text().toInt()-space;
             if(len==0){  //这一块的内存刚好用完，则删除该行
                 tableWidget->removeRow(i);
             }else{
                 tableWidget->item(i,1)->setText(QString::number(len,10));
             }
            return start;
        }
    }
}
//回收内存
void Widget::recycleSpace(PCB *p){
    //回收内存
    int i;
    int pSA=p->startAddress;
    int pAL=p->addressLength;
    for(i=0;i<tableWidget->rowCount();i++){
        if(pSA<tableWidget->item(i,0)->text().toInt()){
            if(i==0){
                int item0SA=tableWidget->item(0,0)->text().toInt();
                int item0AL=tableWidget->item(0,1)->text().toInt();
                if(pSA+pAL==item0SA){//和第一个合并
                    tableWidget->item(0,0)->setText(QString::number(pSA,10));//重设起址
                    tableWidget->item(0,1)->setText(QString::number(pAL+item0AL,10));//重设大小
                }else{               //插入到第一行前面，先插第一行后面，再交换
                    tableWidget->insertRow(0);//新插入的行为第0行
                    QTableWidgetItem *item0,*item1,*item2;
                    item0=new QTableWidgetItem;
                    item1=new QTableWidgetItem;
                    item2=new QTableWidgetItem;

                    item0->setText(QString::number(pSA,10));
                    item1->setText(QString::number(pAL,10));
                    item2->setText(tr("未分"));
                    item0->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
                    item1->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
                    item2->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
                    tableWidget->setRowHeight(0,20);
                    tableWidget->setItem(0,0,item0);
                    tableWidget->setItem(0,1,item1);
                    tableWidget->setItem(0,2,item2);
                }
            }else{
                int foreStartadd=tableWidget->item(i-1,0)->text().toInt();//获取前一行的起址
                int foreAddlen=tableWidget->item(i-1,1)->text().toInt();//获取前一行的大小
                int lastStartadd=tableWidget->item(i,0)->text().toInt();//获取后一行的起址
                int lastAddlen=tableWidget->item(i,1)->text().toInt(); //获取后一行的大小
                if(foreStartadd+foreAddlen==pSA){
                    tableWidget->item(i-1,1)->setText(QString::number((foreAddlen+pAL),10));//和前一个内存空间合并
                    int nowa=tableWidget->item(i-1,1)->text().toInt();
                    if(foreStartadd+nowa==lastStartadd){
                        tableWidget->item(i-1,1)->setText(QString::number(nowa+lastAddlen,10));//和后面一个合并
                        tableWidget->removeRow(i);//删除后面一行
                    }
                }else if(pSA+pAL==lastStartadd){ //和前一行不合并，和后一行合并
                    tableWidget->item(i,0)->setText(QString::number(pSA,10));//重设起址
                    tableWidget->item(i,1)->setText(QString::number(pAL+lastAddlen,10));//重设大小
                }else{                            //都不合并，直接插入
                    tableWidget->insertRow(i);  //在i-1行后面插入，新插入的行作为第i行
                    QTableWidgetItem *item0,*item1,*item2;
                    item0=new QTableWidgetItem;
                    item1=new QTableWidgetItem;
                    item2=new QTableWidgetItem;
                    item0->setText(QString::number(pSA,10));
                    item0->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
                    item1->setText(QString::number(pAL,10));
                    item1->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
                    item2->setText(tr("未分"));
                    item2->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);

                    tableWidget->setRowHeight(i,20);
                    tableWidget->setItem(i,0,item0);
                    tableWidget->setItem(i,1,item1);
                    tableWidget->setItem(i,2,item2);
                }

            }

            return;
        }
    }
    if(i==tableWidget->rowCount()){//最后一行
        tableWidget->insertRow(i-1);
        tableWidget->item(i,0)->setText(QString::number(pSA,10));
        tableWidget->item(i,1)->setText(QString::number(pAL,10));
        tableWidget->item(i,2)->setText(tr("未分"));
    }
    return;
}
