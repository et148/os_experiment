#ifndef WIDGET_H
#define WIDGET_H
#include "readyqueue.h"
#include "comqueue.h"
#include <QWidget>
#include <queue>
#include <QQueue>
#include <algorithm>
#include <iostream>
#include <QTableWidget>
using namespace std;
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
    void addProcess(PCB* p);
    bool ISrun();//判断有没有运行程序
    void updateRun(PCB* p);//对运行线程的更新
    void updateReady();//对就绪队列的更新
    void updatePend(int ok,PCB* p);//对挂起队列的更新
    void updatePool(int ok,PCB* p);//对后备队列的更新
    QString itemShow(PCB* p);//将PCB显示在listWidget中
    bool ISAnySpace(int space);//判断内存够不够
    int divideSpace(int space);//分配内存
    void recycleSpace(PCB* p);//内存回收
private slots:
    void on_addProcess_clicked();//增加线程的信号与槽
    void on_pendProcess_clicked();//挂起线程的信号与槽
private:
    Ui::Widget *ui;
private:
    PCB* runPCB=NULL;
    readyQueue rPCB;//就绪队列
    ComQueue pendprocess;//外部挂起
    ComQueue poolprocess;//后备
    QTableWidget* tableWidget=new QTableWidget(1,3,this);//未分区表

private slots:
    void update();
};

#endif // WIDGET_H
