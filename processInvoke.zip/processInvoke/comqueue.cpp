#include "comqueue.h"
#include <QString>
ComQueue::ComQueue()
{

}
void ComQueue::Push(PCB *pcb){
    PCB* pcb2=node;
    while(pcb2->pcbNext!=NULL){
        pcb2=pcb2->pcbNext;
    }
    pcb2->pcbNext=pcb;
    count++;
}

PCB* ComQueue::Pop(){ 
        PCB* pcb=node->pcbNext;
        node->pcbNext=pcb->pcbNext;
        pcb->pcbNext=NULL;
        count--;
        return pcb;
}

int ComQueue::getCount(){
    return count;
}

void ComQueue::DeQueue(PCB *p){
    PCB* p2=node;
    while(p2->pcbNext!=NULL){
        if(p2->pcbNext->PCBName.compare(p->PCBName)==0){
            p2->pcbNext=p2->pcbNext->pcbNext;//删除该结点
            p->pcbNext=NULL;
            count--;
            return;
        }
        p2=p2->pcbNext;
    }
}

PCB* ComQueue::getPCBByName(QString name){
    PCB* p=node->pcbNext;
    while(p!=NULL){
        if(p->PCBName.compare(name)==0){
            return p;
        }
        p=p->pcbNext;
    }
    return NULL;
}

PCB* ComQueue::getNode(){
    return node;
}
