#ifndef READYQUEUE_H
#define READYQUEUE_H
#include <QString>
class PCB{
public :
    QString PCBName;
    int runTime;
    int priority;
    QString state;
    PCB* pcbNext;
    int  startAddress;
    int addressLength;
    PCB(QString name,int time,int prior,int addlen,int stadd=0,PCB* next=NULL){
         PCBName=name;
         runTime=time;
         priority=prior;
         addressLength=addlen;
         startAddress=stadd;
         pcbNext=next;
    }

};

class readyQueue
{
public:
    readyQueue();
    PCB* Pop();
    bool Push(PCB* pcb);
    void DeQueue(PCB* p);
    int getCount(){
        return count;
    }
    PCB* getNode(){
        return pcbNode;
    }
    PCB* getPCBByName(QString name);
   bool IsReadyQueueEmpty();
private:
    int count=0;
    PCB* pcbNode=new PCB("node",0,0,0,0);
};

#endif // READYQUEUE_H
